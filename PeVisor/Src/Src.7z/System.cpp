#include "System.hpp"
#include <immintrin.h>
#include <intrin.h>
#include <vcruntime_string.h>
/**
 * Function to Copy different buffers.
 * \param dest : Destination buffer.
 * \param src : Source buffer.
 * \param size : Size for copy information.
 * \return : none.
 */
void AVXMemcpy(
	void* dest,
	const void* src,
	size_t size)
{
	const char* s = static_cast<const char*>(src);
	char* d = static_cast<char*>(dest);

	// Check for null pointers
	if (s == nullptr || d == nullptr)
	{
		return;
	}

	// Handle overlapping memory blocks
	if (s < d && s + size > d)
	{
		memmove(d, s, size);
	}
	else if (d < s && d + size > s)
	{
		memmove(d, s, size);
	}
	else
	{
		// Handle unaligned memory blocks
		if (reinterpret_cast<uintptr_t>(s) % 32 == 0 && reinterpret_cast<uintptr_t>(d) % 32 == 0 && size >= 32)
		{
			// Use AVX2 instructions to copy memory
			const size_t avx2_size = size / (32 * 16);
			const size_t remainder_size = size % (32 * 16);
			const __m256i* src_avx2 = reinterpret_cast<const __m256i*>(s);
			__m256i* dest_avx2 = reinterpret_cast<__m256i*>(d);
			for (size_t i = 0; i < avx2_size; ++i)
			{
				 __m256i ymm0 = _mm256_load_si256(src_avx2++);
				 __m256i ymm1 = _mm256_load_si256(src_avx2++);
				 __m256i ymm2 = _mm256_load_si256(src_avx2++);
				 __m256i ymm3 = _mm256_load_si256(src_avx2++);
				 __m256i ymm4 = _mm256_load_si256(src_avx2++);
				 __m256i ymm5 = _mm256_load_si256(src_avx2++);
				 __m256i ymm6 = _mm256_load_si256(src_avx2++);
				 __m256i ymm7 = _mm256_load_si256(src_avx2++);
				 __m256i ymm8 = _mm256_load_si256(src_avx2++);
				 __m256i ymm9 = _mm256_load_si256(src_avx2++);
				 __m256i ymm10 = _mm256_load_si256(src_avx2++);
				 __m256i ymm11 = _mm256_load_si256(src_avx2++);
				 __m256i ymm12 = _mm256_load_si256(src_avx2++);
				 __m256i ymm13 = _mm256_load_si256(src_avx2++);
				 __m256i ymm14 = _mm256_load_si256(src_avx2++);
				 __m256i ymm15 = _mm256_load_si256(src_avx2++);
				_mm256_store_si256(dest_avx2++, ymm0);
				_mm256_store_si256(dest_avx2++, ymm1);
				_mm256_store_si256(dest_avx2++, ymm2);
				_mm256_store_si256(dest_avx2++, ymm3);
				_mm256_store_si256(dest_avx2++, ymm4);
				_mm256_store_si256(dest_avx2++, ymm5);
				_mm256_store_si256(dest_avx2++, ymm6);
				_mm256_store_si256(dest_avx2++, ymm7);
				_mm256_store_si256(dest_avx2++, ymm8);
				_mm256_store_si256(dest_avx2++, ymm9);
				_mm256_store_si256(dest_avx2++, ymm10);
				_mm256_store_si256(dest_avx2++, ymm11);
				_mm256_store_si256(dest_avx2++, ymm12);
				_mm256_store_si256(dest_avx2++, ymm13);
				_mm256_store_si256(dest_avx2++, ymm14);
				_mm256_store_si256(dest_avx2++, ymm15);
			}
			memcpy(dest_avx2, src_avx2, remainder_size);
		}
		else
		{
			// Use standard memcpy for unaligned memory blocks
			memcpy(dest, src, size);
		}
	}
}

void SSEMemory(
	void* dest,
	const void* src,
	size_t size)
{
	const char* s = static_cast<const char*>(src);
	char* d = static_cast<char*>(dest);

	// Check for null pointers
	if (s == nullptr || d == nullptr)
	{
		return;
	}

	// Handle overlapping memory blocks
	if (s < d && s + size > d)
	{
		memmove(d, s, size);
	}
	else if (d < s && d + size > s)
	{
		memmove(d, s, size);
	}
	else
	{
		// Handle unaligned memory blocks
		if (reinterpret_cast<uintptr_t>(s) % 16 == 0 && reinterpret_cast<uintptr_t>(d) % 16 == 0 && size >= 16)
		{
			// Use SSE instructions to copy memory
			const size_t sse_size = size / (16 * 16);
			const size_t remainder_size = size % (16 * 16);
			const __m128i* src_sse = reinterpret_cast<const __m128i*>(s);
			__m128i* dest_sse = reinterpret_cast<__m128i*>(d);
			for (size_t i = 0; i < sse_size; ++i)
			{
				__m128i xmm0 = _mm_load_si128(src_sse++);
				__m128i xmm1 = _mm_load_si128(src_sse++);
				__m128i xmm2 = _mm_load_si128(src_sse++);
				__m128i xmm3 = _mm_load_si128(src_sse++);
				__m128i xmm4 = _mm_load_si128(src_sse++);
				__m128i xmm5 = _mm_load_si128(src_sse++);
				__m128i xmm6 = _mm_load_si128(src_sse++);
				__m128i xmm7 = _mm_load_si128(src_sse++);
				__m128i xmm8 = _mm_load_si128(src_sse++);
				__m128i xmm9 = _mm_load_si128(src_sse++);
				__m128i xmm10 = _mm_load_si128(src_sse++);
				__m128i xmm11 = _mm_load_si128(src_sse++);
				__m128i xmm12 = _mm_load_si128(src_sse++);
				__m128i xmm13 = _mm_load_si128(src_sse++);
				__m128i xmm14 = _mm_load_si128(src_sse++);
				__m128i xmm15 = _mm_load_si128(src_sse++);
				_mm_store_si128(dest_sse++, xmm0);
				_mm_store_si128(dest_sse++, xmm1);
				_mm_store_si128(dest_sse++, xmm2);
				_mm_store_si128(dest_sse++, xmm3);
				_mm_store_si128(dest_sse++, xmm4);
				_mm_store_si128(dest_sse++, xmm5);
				_mm_store_si128(dest_sse++, xmm6);
				_mm_store_si128(dest_sse++, xmm7);
				_mm_store_si128(dest_sse++, xmm8);
				_mm_store_si128(dest_sse++, xmm9);
				_mm_store_si128(dest_sse++, xmm10);
				_mm_store_si128(dest_sse++, xmm11);
				_mm_store_si128(dest_sse++, xmm12);
				_mm_store_si128(dest_sse++, xmm13);
				_mm_store_si128(dest_sse++, xmm14);
				_mm_store_si128(dest_sse++, xmm15);
			}
			memcpy(dest_sse, src_sse, remainder_size);
		}
		else
		{
			// Use standard memcpy for unaligned memory blocks
			memcpy(dest, src, size);
		}
	}
}
