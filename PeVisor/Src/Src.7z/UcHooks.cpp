#include "UcHooks.hpp"

namespace ucHooks {
	void HookCode(uc_engine* uc, DWORD_PTR address, size_t size, void* user_data)
	{
		printf("%p\n", address);
	}

	void HookBlock(uc_engine* uc, DWORD_PTR address, size_t size, void* user_data)
	{
		//printf("%p\n", address);
	}

	void HookEdgeGenerated(uc_engine* uc, DWORD_PTR address, size_t size, void* user_data)
	{
		//uint64_t Rip = 0;
		//uc_reg_read(uc, UC_X86_REG_RIP, &Rip);
		//printf("%p\n", Rip);
	}

	void HookInt(uc_engine* uc, DWORD_PTR address, size_t size, void* user_data)
	{

	}
}