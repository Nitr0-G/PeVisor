#ifndef SYSTEM_H
#define SYSTEM_H
/**
 * Function to Copy different buffers.
 * \param dest : Destination buffer.
 * \param src : Source buffer.
 * \param size : Size for copy information.
 * \return : none.
 */
void AVXMemcpy(
	void* dest,
	const void* src,
	size_t size);

/**
 * Function to Copy different buffers.
 * \param dest : Destination buffer.
 * \param src : Source buffer.
 * \param size : Size for copy information.
 * \return : none.
 */
void SSEMemory(
	void* dest,
	const void* src,
	size_t size);

#endif