#include "Pe.hpp"

/**
 * Function to retrieve the PE EXE file content.
 * \return address of the dos header.
 */
PIMAGE_DOS_HEADER Pe::LoadExeFileIntoMemory()
{
    const HANDLE hFile = CreateFileA(InfoPe->Path.string().data(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
    if (hFile == INVALID_HANDLE_VALUE)
    {
        printf("[-] An error occured when trying to open the PE file !");
        CloseHandle(hFile);
        return nullptr;
    }

    const DWORD dFileSize = GetFileSize(hFile, nullptr);
    if (dFileSize == INVALID_FILE_SIZE)
    {
        printf("[-] An error occured when trying to get the PE file size !");
        CloseHandle(hFile);
        return nullptr;
    }

    LPVOID hFileContent = VirtualAlloc(nullptr, dFileSize, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    if (hFileContent == nullptr)
    {
        printf("[-] An error occured when trying to allocate memory for the PE file content !");
        CloseHandle(hFile);
        return nullptr;
    }

    const BOOL bFileRead = ReadFile(hFile, hFileContent, dFileSize, nullptr, nullptr);
    if (!bFileRead)
    {
        printf("[-] An error occured when trying to read the PE file content !");
        CloseHandle(hFile);
        VirtualFree(hFileContent, 0, MEM_RELEASE);

        return nullptr;
    }

    CloseHandle(hFile);
    return (PIMAGE_DOS_HEADER)hFileContent;
}

/**
 * Function to retrieve the PE DLL file content.
 * \param Name of dll
 * \return address of the dos header.
 */
PIMAGE_DOS_HEADER Pe::LoadDllFileIntoMemory(const char* DllName)
{
    SetDllDirectoryA(InfoPe->Path.parent_path().string().c_str());

    PIMAGE_DOS_HEADER DosHeader = (PIMAGE_DOS_HEADER)LoadLibraryA(DllName);
    if (DosHeader == nullptr)
    {
        return nullptr;
    }

    return DosHeader;
}

/**
 * Function to unload the PE file content.
 * \return True if success || False if unsuccess
 */
bool Pe::UnloadFileFromMemory()
{
    return HeapFree((HANDLE)InfoPe->PeStructure.DosHeader, 0, nullptr);
}

void Pe::UcHeaderSectionMapping(PIMAGE_SECTION_HEADER pImageSectionHeader, PIMAGE_DOS_HEADER* DosHeader, PIMAGE_NT_HEADERS* NtHeader, bool Dll, std::vector<IMAGE_SECTION_HEADER> Sections, LPVOID* SectionBaseAddress)
{
    size_t SectionSizeHeader = ((*NtHeader)->OptionalHeader.SizeOfHeaders + (*NtHeader)->OptionalHeader.SectionAlignment - 1) &
        ~((*NtHeader)->OptionalHeader.SectionAlignment - 1);

    // Create a temporary IMAGE_SECTION_HEADER for the initial section
    IMAGE_SECTION_HEADER initialSectionHeader;
    ZeroMemory(&initialSectionHeader, sizeof(IMAGE_SECTION_HEADER));
    initialSectionHeader.VirtualAddress = 0; // Assuming it starts at the beginning of the image
    initialSectionHeader.PointerToRawData = (*DosHeader)->e_lfanew + sizeof(IMAGE_NT_HEADERS) + (*NtHeader)->FileHeader.SizeOfOptionalHeader; // Adjust this if necessary
    initialSectionHeader.SizeOfRawData = SectionSizeHeader;

    Sections.push_back(initialSectionHeader);

    uc_err ErrorOfMapping = UC_ERR_OK;

    if (Dll)
    {
        //int cpuInfo[4];
        //__cpuid(cpuInfo, 0);
        //if (cpuInfo[0] >= 7)
        //{
        //    __cpuidex(cpuInfo, 7, 0);
        //    if (cpuInfo[1] & (1 << 5))
        //    {
        //        AVXMemcpy(*SectionBaseAddress, LPVOID(*DosHeader), SectionSizeHeader);
        //    }
        //    else
        //    {
        //        SSEMemory(*SectionBaseAddress, LPVOID(*DosHeader), SectionSizeHeader);
        //    }
        //}

        *DosHeader = (PIMAGE_DOS_HEADER)*SectionBaseAddress;
        *NtHeader = (PIMAGE_NT_HEADERS)((DWORD_PTR)*DosHeader + (*DosHeader)->e_lfanew);

        ErrorOfMapping = uc_mem_map_ptr(
            uc,
            //ALIGN_TO_4KB(DWORD_PTR(initialSectionHeader.VirtualAddress + (*NtHeader)->OptionalHeader.ImageBase)),
            ALIGN_TO_4KB(DWORD_PTR(*SectionBaseAddress)),
            SectionSizeHeader,
            UC_PROT_ALL,
            (void*)(*SectionBaseAddress));

        *SectionBaseAddress = (LPVOID)((DWORD_PTR)(*SectionBaseAddress) + SectionSizeHeader);
    }
    else
    {
        // Map the initial section
        ErrorOfMapping = uc_mem_map_ptr(
            uc,
            ALIGN_TO_4KB(DWORD_PTR(initialSectionHeader.VirtualAddress + (*NtHeader)->OptionalHeader.ImageBase)),
            SectionSizeHeader,
            UC_PROT_ALL,
            (void*)(*DosHeader));
    }

    if (ErrorOfMapping != UC_ERR_OK)
    {
        printf("Failed on uc_mem_map_ptr() with error returned %u: %s\n", ErrorOfMapping, uc_strerror(ErrorOfMapping));
        return;
    }

    return;
}

/**
 * Function for unicorn section mapping.
 * \param 
 * pImageSectionHeader: pointer to section header of all sections
 * \return True if success || False if unsuccess
 */
void Pe::UcSectionMapping(PIMAGE_SECTION_HEADER pImageSectionHeader, PIMAGE_DOS_HEADER* DosHeader, PIMAGE_NT_HEADERS* NtHeader, bool Dll)
{
    LPVOID SectionBaseAddress = nullptr;
    if (Dll)
    {
        size_t SectionSizeHeader = ((*NtHeader)->OptionalHeader.SizeOfHeaders + (*NtHeader)->OptionalHeader.SectionAlignment - 1) &
            ~((*NtHeader)->OptionalHeader.SectionAlignment - 1);

        size_t TotalSize = SectionSizeHeader;

        for (DWORD_PTR Index = 0; Index < (*NtHeader)->FileHeader.NumberOfSections; ++Index)
        {
            TotalSize += ((pImageSectionHeader[Index].SizeOfRawData + (*NtHeader)->OptionalHeader.SectionAlignment - 1) &
                ~((*NtHeader)->OptionalHeader.SectionAlignment - 1));
        }

        SectionBaseAddress = VirtualAlloc(nullptr, TotalSize, MEM_COMMIT, PAGE_READWRITE);

        int cpuInfo[4];
        __cpuid(cpuInfo, 0);
        if (cpuInfo[0] >= 7)
        {
            __cpuidex(cpuInfo, 7, 0);
            if (cpuInfo[1] & (1 << 5))
            {
                AVXMemcpy(SectionBaseAddress, LPVOID(*DosHeader), TotalSize);
            }
            else
            {
                SSEMemory(SectionBaseAddress, LPVOID(*DosHeader), TotalSize);
            }
        }
    }

    std::vector<IMAGE_SECTION_HEADER> Sections;

    UcHeaderSectionMapping(pImageSectionHeader, DosHeader, NtHeader, Dll, Sections, &SectionBaseAddress);

    for (DWORD_PTR Index = 0; Index < (*NtHeader)->FileHeader.NumberOfSections; ++Index)
    {
        size_t SectionSize = ((pImageSectionHeader[Index].SizeOfRawData + (*NtHeader)->OptionalHeader.SectionAlignment - 1) &
            ~((*NtHeader)->OptionalHeader.SectionAlignment - 1));

        Sections.push_back(pImageSectionHeader[Index]);

        uc_err ErrorOfMapping = UC_ERR_OK;

        if (Dll)
        {
            //int cpuInfo[4];
            //__cpuid(cpuInfo, 0);
            //if (cpuInfo[0] >= 7)
            //{
            //    __cpuidex(cpuInfo, 7, 0);
            //    if (cpuInfo[1] & (1 << 5))
            //    {
            //        AVXMemcpy(SectionBaseAddress, LPVOID(pImageSectionHeader[Index].PointerToRawData + (DWORD_PTR)*DosHeader), SectionSize);
            //    }
            //    else
            //    {
            //        SSEMemory(SectionBaseAddress, LPVOID(pImageSectionHeader[Index].PointerToRawData + (DWORD_PTR)*DosHeader), SectionSize);
            //    }
            //}

            ErrorOfMapping = uc_mem_map_ptr(
                uc,
                //ALIGN_TO_4KB(DWORD_PTR(pImageSectionHeader[Index].VirtualAddress + (*NtHeader)->OptionalHeader.ImageBase)),
                ALIGN_TO_4KB(DWORD_PTR(SectionBaseAddress)),
                SectionSize,
                UC_PROT_ALL,
                (void*)(SectionBaseAddress));

            SectionBaseAddress = (LPVOID)((DWORD_PTR)SectionBaseAddress + SectionSize);
        }
        else
        {
            ErrorOfMapping = uc_mem_map_ptr(
                uc,
                ALIGN_TO_4KB(DWORD_PTR(pImageSectionHeader[Index].VirtualAddress + (*NtHeader)->OptionalHeader.ImageBase)),
                SectionSize,
                UC_PROT_ALL,
                (void*)(pImageSectionHeader[Index].PointerToRawData + (DWORD_PTR)*DosHeader));
        }

        if (ErrorOfMapping != UC_ERR_OK)
        {
            printf("Failed on uc_mem_map_ptr() with error returned %u: %s\n", ErrorOfMapping, uc_strerror(ErrorOfMapping));
            return;
        }
    }

    InfoPe->PeStructure.svSections.push_back(Sections);
}

uint32_t fnv1a_32(const std::string& str) {
    uint32_t hash = 2166136261; // FNV offset basis
    for (char c : str) {
        hash ^= c; // XOR the hash with the character
        hash *= 16777619; // Multiply by the FNV prime
    }
    return hash;
}

auto Pe::FindDllByHash(uint32_t hashToFind) {
    auto it = std::find_if(ProcessedDlls.begin(), ProcessedDlls.end(),
        [hashToFind](const ProcessedDll& dll) {
            return dll.Hash == hashToFind;
        });
    return it;
}

auto Pe::FindDllByOrigDosHeaderDll(PIMAGE_DOS_HEADER OrigDosHeaderDll) {
    auto it = std::find_if(ProcessedDlls.begin(), ProcessedDlls.end(),
        [OrigDosHeaderDll](const ProcessedDll& dll) {
            return (DWORD_PTR)dll.OrigDosHeader == (DWORD_PTR)OrigDosHeaderDll;
        });
    return it;
}

bool Pe::ResolveImports(PIMAGE_NT_HEADERS* NtHeader_, PIMAGE_DOS_HEADER* DosHeader_, PIMAGE_DOS_HEADER OrigDosHeaderDll_)
{
    PIMAGE_NT_HEADERS NtHeader = *NtHeader_;
    PIMAGE_DOS_HEADER DosHeader = *DosHeader_;

    PIMAGE_SECTION_HEADER pImageImportHeader = nullptr;
    PIMAGE_IMPORT_DESCRIPTOR pImageImportDescriptor = nullptr;
    PIMAGE_THUNK_DATA pFirstThrunk = nullptr;
    PIMAGE_THUNK_DATA pOriginalFirstThrunk = nullptr;

    if (NtHeader == nullptr || DosHeader == nullptr) { return false; }

    const PIMAGE_SECTION_HEADER pImageSectionHeader =
        (PIMAGE_SECTION_HEADER)((DWORD_PTR)NtHeader + 4 +
            sizeof(IMAGE_FILE_HEADER) + NtHeader->FileHeader.SizeOfOptionalHeader);

    if (pImageSectionHeader == nullptr) { return false; }

    FIND_IMAGE_DIRECTORY_ENTRY(NtHeader, IMAGE_DIRECTORY_ENTRY_IMPORT, pImageSectionHeader, pImageImportHeader);

    if (pImageImportHeader == nullptr) 
    {
        //UcSectionMapping(pImageSectionHeader, &DosHeader, &NtHeader, true); 

        *NtHeader_ = NtHeader;
        *DosHeader_ = DosHeader;

        return false;
    }

    const DWORD_PTR dRawOffset = (DWORD_PTR)DosHeader + pImageImportHeader->PointerToRawData;

    pImageImportDescriptor = (PIMAGE_IMPORT_DESCRIPTOR)(dRawOffset + (NtHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress - pImageImportHeader->VirtualAddress));

    if (pImageImportDescriptor == NULL) { return false; }

    while (pImageImportDescriptor->Name != 0)
    {
        //Need to load dll into memory, i.e. our dll must be independent from our parent(for example PeVisor.exe) executable because we doing emulation of all stuff
        const std::string_view DllName = (char*)(dRawOffset + (pImageImportDescriptor->Name - pImageImportHeader->VirtualAddress));

        PIMAGE_DOS_HEADER DosHeaderDll = LoadDllFileIntoMemory(DllName.data());
        PIMAGE_NT_HEADERS NtHeaderDll = (PIMAGE_NT_HEADERS)((DWORD_PTR)DosHeaderDll + DosHeaderDll->e_lfanew);
        PIMAGE_DOS_HEADER OrigDosHeaderDll = DosHeaderDll;

        if (OrigDosHeaderDll == OrigDosHeaderDll_) { return true; }

        PIMAGE_SECTION_HEADER pImageSectionHeaderDll =
            (PIMAGE_SECTION_HEADER)((DWORD_PTR)NtHeaderDll + 4 +
                sizeof(IMAGE_FILE_HEADER) + NtHeaderDll->FileHeader.SizeOfOptionalHeader);

        auto foundDll = FindDllByHash(fnv1a_32(DllName.data()));
        if (foundDll == ProcessedDlls.end()) {
            auto foundDllDosHeader = FindDllByOrigDosHeaderDll(OrigDosHeaderDll);
            if (foundDllDosHeader == ProcessedDlls.end()) {
                UcSectionMapping(pImageSectionHeaderDll, &DosHeaderDll, &NtHeaderDll, true);

                ResolveImports(&NtHeaderDll, &DosHeaderDll, OrigDosHeaderDll);

                ProcessedDlls.push_back({ fnv1a_32(DllName.data()), DllName, DosHeaderDll, NtHeaderDll, OrigDosHeaderDll });
            }
            else
            {
                DosHeaderDll = foundDllDosHeader->DosHeader;
                NtHeaderDll = foundDllDosHeader->NtHeader;
            }
        }
        else
        {
            DosHeaderDll = foundDll->DosHeader;
            NtHeaderDll = foundDll->NtHeader;
        }
        //if (IAT)
        //{
        //    UcSectionMapping(pImageSectionHeaderDll, &DosHeaderDll, &NtHeaderDll, true);
        //}

        pFirstThrunk = (PIMAGE_THUNK_DATA)(dRawOffset + (pImageImportDescriptor->FirstThunk - pImageImportHeader->VirtualAddress));
        pOriginalFirstThrunk = (PIMAGE_THUNK_DATA)(dRawOffset + (pImageImportDescriptor->OriginalFirstThunk - pImageImportHeader->VirtualAddress));

        while (pFirstThrunk->u1.AddressOfData != 0)
        {
            if (pFirstThrunk->u1.AddressOfData >= IMAGE_ORDINAL_FLAG64) { ++pFirstThrunk; continue; }

            PIMAGE_IMPORT_BY_NAME pImageImportByName =
                (PIMAGE_IMPORT_BY_NAME)(dRawOffset + (pOriginalFirstThrunk->u1.AddressOfData - pImageImportHeader->VirtualAddress));

            if (pImageImportByName == nullptr) { continue; }

            FARPROC pfnProc = nullptr;

            if (IMAGE_SNAP_BY_ORDINAL(pOriginalFirstThrunk->u1.Ordinal))
            {
                //printf("%s\n", (LPCSTR)pOriginalFirstThrunk->u1.Ordinal);
                pfnProc = GetProcAddress((HMODULE)OrigDosHeaderDll, (LPCSTR)(uint32_t)pOriginalFirstThrunk->u1.Ordinal);
                pfnProc = (FARPROC)((DWORD_PTR)DosHeaderDll + ((DWORD_PTR)pfnProc - (DWORD_PTR)OrigDosHeaderDll));
            }
            else
            {
                //printf("%s\n", pImageImportByName->Name);
                pfnProc = GetProcAddress((HMODULE)OrigDosHeaderDll, (LPCSTR)pImageImportByName->Name);
                pfnProc = (FARPROC)((DWORD_PTR)DosHeaderDll + ((DWORD_PTR)pfnProc - (DWORD_PTR)OrigDosHeaderDll));
            }

            if (pfnProc == nullptr) { return false; }
            pFirstThrunk->u1.Function = (ULONG_PTR)pfnProc;

            ++pFirstThrunk;
            ++pOriginalFirstThrunk;
        }
        ++pImageImportDescriptor;
    }

    *NtHeader_ = NtHeader;
    *DosHeader_ = DosHeader;

    return true;
}

Pe::Pe(std::shared_ptr<_InfoPe> infoPe, uc_engine* Uc) : InfoPe(infoPe), uc(Uc)
{
    InfoPe->PeStructure.DosHeader = LoadExeFileIntoMemory();
    InfoPe->PeStructure.NtHeader = (PIMAGE_NT_HEADERS)((DWORD_PTR)InfoPe->PeStructure.DosHeader + InfoPe->PeStructure.DosHeader->e_lfanew);
    InfoPe->PeStructure.EntryPoint = InfoPe->PeStructure.NtHeader->OptionalHeader.AddressOfEntryPoint + InfoPe->PeStructure.NtHeader->OptionalHeader.ImageBase;

    PIMAGE_SECTION_HEADER pImageSectionHeader =
        (PIMAGE_SECTION_HEADER)((DWORD_PTR)InfoPe->PeStructure.NtHeader + 4 +
            sizeof(IMAGE_FILE_HEADER) + InfoPe->PeStructure.NtHeader->FileHeader.SizeOfOptionalHeader);

    ResolveImports(&InfoPe->PeStructure.NtHeader, &InfoPe->PeStructure.DosHeader, nullptr);

    UcSectionMapping(pImageSectionHeader, &InfoPe->PeStructure.DosHeader, &InfoPe->PeStructure.NtHeader, false);

	return;
}