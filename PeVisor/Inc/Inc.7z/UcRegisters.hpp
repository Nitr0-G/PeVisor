#ifndef UNICORN_REGISTERS
#define UNICORN_REGISTERS

#include "unicorn\x86.h"
#include <basetsd.h>
#include <string_view>
#include <vector>
#include <xmmintrin.h>

#pragma pack(push, 1)
struct SegmentDescriptor {
    union {
        struct {
#if __BYTE_ORDER == __LITTLE_ENDIAN
            unsigned short limit0;
            unsigned short base0;
            unsigned char base1;
            unsigned char type : 4;
            unsigned char system : 1; /* S flag */
            unsigned char dpl : 2;
            unsigned char present : 1; /* P flag */
            unsigned char limit1 : 4;
            unsigned char avail : 1;
            unsigned char is_64_code : 1;  /* L flag */
            unsigned char db : 1;          /* DB flag */
            unsigned char granularity : 1; /* G flag */
            unsigned char base2;
#else
            unsigned char base2;
            unsigned char granularity : 1; /* G flag */
            unsigned char db : 1;          /* DB flag */
            unsigned char is_64_code : 1;  /* L flag */
            unsigned char avail : 1;
            unsigned char limit1 : 4;
            unsigned char present : 1; /* P flag */
            unsigned char dpl : 2;
            unsigned char system : 1; /* S flag */
            unsigned char type : 4;
            unsigned char base1;
            unsigned short base0;
            unsigned short limit0;
#endif
        };
        uint64_t desc;
    };
};
#pragma pack(pop)

class _GeneralPurposeUcRegisters {
private:
    uint32_t AlignNumber = 0x1000;
public:
    struct SegmentDescriptor* GDT = (struct SegmentDescriptor*)calloc(
        63, sizeof(struct SegmentDescriptor));

    uc_x86_mmr GDTR;

    DWORD_PTR GdtAddress = 0xc0000000;
    DWORD_PTR StackAddress = 0x120000;
    DWORD_PTR FsAddress = 0x7efdd000;

    std::vector<DWORD_PTR> svUcValuesOfRegs{
        0x0,//(0)RAX
        0x0,//(1)RBX
        0x0,//(2)RCX
        0x0,//(3)RDX
        0x0,//(4)RSI
        0x0,//(5)RDI 
        0x0,//(6)R8 
        0x0,//(7)R9 
        0x0,//(8)R10
        0x0,//(9)R11 
        0x0,//(10)R12 
        0x0,//(11)R13 
        0x0,//(12)R14 
        0x0,//(13)R15 
        0x0,//(14)RFLAGS 
        StackAddress + AlignNumber,//(15)RSP
        0x0,//(16)RBP
        0x0,//(17)RIP
        0x88,//(18)SS
        0x73,//(19)CS
        0x7B,//(20)DS
        0x7B,//(21)ES
        0x83,//(22)FS
    };

    std::vector<std::string_view> szovGeneralPurposeUcRegisters{
        ">>> RAX = ",
        ">>> RBX = ",
        ">>> RCX = ",
        ">>> RDX = ",
        ">>> RSI = ",
        ">>> RDI = ",
        ">>> R8  = ",
        ">>> R9  = ",
        ">>> R10 = ",
        ">>> R11 = ",
        ">>> R12 = ",
        ">>> R13 = ",
        ">>> R14 = ",
        ">>> R15 = ",
        ">>> RFLAGS = ",
        ">>> RSP = ",
        ">>> RBP = ",
        ">>> RIP = ",
        ">>> GS = "//
    };

    std::vector<uc_x86_reg> svUcIdsOfRegs{
        UC_X86_REG_RAX,
        UC_X86_REG_RBX,
        UC_X86_REG_RCX,
        UC_X86_REG_RDX,
        UC_X86_REG_RSI,
        UC_X86_REG_RDI,
        UC_X86_REG_R8,
        UC_X86_REG_R9,
        UC_X86_REG_R10,
        UC_X86_REG_R11,
        UC_X86_REG_R12,
        UC_X86_REG_R13,
        UC_X86_REG_R14,
        UC_X86_REG_R15,
        UC_X86_REG_RFLAGS,
        UC_X86_REG_RSP,
        UC_X86_REG_RBP,
        UC_X86_REG_RIP,
        UC_X86_REG_SS,
        UC_X86_REG_CS,
        UC_X86_REG_DS,
        UC_X86_REG_ES,
        UC_X86_REG_FS
    };
};

class _XmmUcRegisters {
public:
    std::vector<__m128> svUcValuesOfRegs{
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps(),
        _mm_setzero_ps()
    };

    std::vector<std::string_view> szovXmmUcRegisters{
        ">>> XMM0 = ",
        ">>> XMM1 = ",
        ">>> XMM2 = ",
        ">>> XMM3 = ",
        ">>> XMM4 = ",
        ">>> XMM5 = ",
        ">>> XMM6 = ",
        ">>> XMM7 = ",
        ">>> XMM8 = ",
        ">>> XMM9 = ",
        ">>> XMM10 = ",
        ">>> XMM11 = ",
        ">>> XMM12 = ",
        ">>> XMM13 = ",
        ">>> XMM14 = ",
        ">>> XMM15 = "
    };

    std::vector<uc_x86_reg> svUcIdsOfRegs{
        UC_X86_REG_XMM0,
        UC_X86_REG_XMM1,
        UC_X86_REG_XMM2,
        UC_X86_REG_XMM3,
        UC_X86_REG_XMM4,
        UC_X86_REG_XMM5,
        UC_X86_REG_XMM6,
        UC_X86_REG_XMM7,
        UC_X86_REG_XMM8,
        UC_X86_REG_XMM9,
        UC_X86_REG_XMM10,
        UC_X86_REG_XMM11,
        UC_X86_REG_XMM12,
        UC_X86_REG_XMM13,
        UC_X86_REG_XMM14,
        UC_X86_REG_XMM15
    };
};

class _UcRegisters {
public:
    class _GeneralPurposeUcRegisters GeneralPurposeUcRegisters {};
    class _XmmUcRegisters XmmUcRegisters {};
};

#endif