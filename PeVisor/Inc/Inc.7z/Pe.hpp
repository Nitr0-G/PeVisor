#ifndef PE_CLASS
#define PE_CLASS

#include "System.hpp"
#include "InfoPe.hpp"
#include "unicorn\unicorn.h"
#include <basetsd.h>
#include <filesystem>
#include <memory>
#include <Windows.h>

#define FIND_IMAGE_DIRECTORY_ENTRY(NtHeader, ImageDirectoryEntryType, pImageSectionHeader, pImageDirectoryEntryHeader) \
    for (unsigned char Section = 0; Section < NtHeader->FileHeader.NumberOfSections; ++Section) \
    { \
        PIMAGE_SECTION_HEADER pCurrentSectionHeader = \
            (PIMAGE_SECTION_HEADER)((DWORD_PTR)pImageSectionHeader + \
                Section * sizeof(IMAGE_SECTION_HEADER)); \
 \
        if (NtHeader->OptionalHeader.DataDirectory[ImageDirectoryEntryType].VirtualAddress >= pCurrentSectionHeader->VirtualAddress && \
            NtHeader->OptionalHeader.DataDirectory[ImageDirectoryEntryType].VirtualAddress < \
            pCurrentSectionHeader->VirtualAddress + pCurrentSectionHeader->Misc.VirtualSize) \
        { \
            pImageDirectoryEntryHeader = pCurrentSectionHeader; \
            break; \
        } \
    }

#define ALIGN_TO_4KB(size) (((size) + 4095) / 4096) * 4096

typedef struct ProcessedDll_
{
    const uint32_t Hash;
    std::string_view DllName;
    PIMAGE_DOS_HEADER DosHeader;
    PIMAGE_NT_HEADERS NtHeader;
    PIMAGE_DOS_HEADER OrigDosHeader;
} ProcessedDll, *PProcessedDll_;

class Pe {
private:
	std::shared_ptr<_InfoPe> InfoPe;

	uc_engine* uc = nullptr;

    std::vector<ProcessedDll> ProcessedDlls;
private:
    auto FindDllByHash(uint32_t hashToFind);
    auto FindDllByOrigDosHeaderDll(PIMAGE_DOS_HEADER OrigDosHeaderDll);

	PIMAGE_DOS_HEADER LoadExeFileIntoMemory();
	PIMAGE_DOS_HEADER LoadDllFileIntoMemory(const char* DllName);

	void UcSectionMapping(PIMAGE_SECTION_HEADER pImageSectionHeader, PIMAGE_DOS_HEADER* DosHeader, PIMAGE_NT_HEADERS* NtHeader, bool Dll);
    void UcHeaderSectionMapping(PIMAGE_SECTION_HEADER pImageSectionHeader, PIMAGE_DOS_HEADER* DosHeader, PIMAGE_NT_HEADERS* NtHeader, bool Dll, std::vector<IMAGE_SECTION_HEADER> Sections, LPVOID* SectionBaseAddress);

	bool ResolveImports(PIMAGE_NT_HEADERS* NtHeader_, PIMAGE_DOS_HEADER* DosHeader_, PIMAGE_DOS_HEADER OrigDosHeaderDll_);
public:
	bool UnloadFileFromMemory();

	Pe(std::shared_ptr<_InfoPe> infoPe, uc_engine* Uc);
};

#endif