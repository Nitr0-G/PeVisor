#include "Unicorn.hpp"

int main()
{
	Unicorn Unicorn;
	return 0;
}