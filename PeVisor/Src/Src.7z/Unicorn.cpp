#include "Unicorn.hpp"

void init_descriptor(struct SegmentDescriptor* desc, DWORD_PTR base,
    DWORD_PTR limit, uint8_t is_code)
{
    desc->desc = 0; // clear the descriptor
    desc->base0 = base & 0xffff;
    desc->base1 = (base >> 16) & 0xff;
    desc->base2 = (base >> 24) & 0xff;
    //desc->base3 = (base >> 32) & 0xff;
    if (limit > 0xfffff) {
        // need Giant granularity
        limit >>= 12;
        desc->granularity = 1;
    }
    desc->limit0 = limit & 0xffff;
    desc->limit1 = limit >> 16;

    // some sane defaults
    desc->dpl = 3;
    desc->present = 1;
    desc->db = 1; // 32 bit
    desc->type = is_code ? 0xb : 3;
    desc->system = 1; // code or data
}

void Unicorn::UcDefualtRegsInit()
{
    UcRegisters->GeneralPurposeUcRegisters.GDTR.base = UcRegisters->GeneralPurposeUcRegisters.GdtAddress;
    UcRegisters->GeneralPurposeUcRegisters.GDTR.limit = 63 * sizeof(struct SegmentDescriptor) - 1;

    init_descriptor(&UcRegisters->GeneralPurposeUcRegisters.GDT[14], 0, 0xfffff000, 1); // code segment
    init_descriptor(&UcRegisters->GeneralPurposeUcRegisters.GDT[15], 0, 0xfffff000, 0); // data segment
    init_descriptor(&UcRegisters->GeneralPurposeUcRegisters.GDT[16], 0x7efdd000, 0xfff,
        0); // one page data segment simulate fs
    init_descriptor(&UcRegisters->GeneralPurposeUcRegisters.GDT[17], 0, 0xfffff000, 0); // ring 0 data
    UcRegisters->GeneralPurposeUcRegisters.GDT[17].dpl = 0; // set descriptor privilege level
}

void Unicorn::UcDefualtSectionMapping()
{
    //Stack allocation
    uc_mem_map(uc, ALIGN_TO_4KB(UcRegisters->GeneralPurposeUcRegisters.StackAddress), ALIGN_TO_4KB(InfoPe->PeStructure.NtHeader->OptionalHeader.SizeOfStackReserve), UC_PROT_ALL);

    //Gdt allocation
    //Attention!!! = set up a GDT(UC_X86_REG_GDTR) BEFORE you manipulate any segment registers
    uc_mem_map(uc, ALIGN_TO_4KB(UcRegisters->GeneralPurposeUcRegisters.GdtAddress), ALIGN_TO_4KB((DWORD_PTR)DefualtSizesForSectionMapping::GdtSize), UC_PROT_WRITE | UC_PROT_READ);

    uc_reg_write(uc, UC_X86_REG_GDTR, &UcRegisters->GeneralPurposeUcRegisters.GDTR);

    uc_mem_write(uc, ALIGN_TO_4KB(UcRegisters->GeneralPurposeUcRegisters.GdtAddress), UcRegisters->GeneralPurposeUcRegisters.GDT,
        63 * sizeof(struct SegmentDescriptor));

    //Fs allocation
    uc_mem_map(uc, ALIGN_TO_4KB(UcRegisters->GeneralPurposeUcRegisters.FsAddress), ALIGN_TO_4KB((DWORD_PTR)DefualtSizesForSectionMapping::FsSize), UC_PROT_WRITE | UC_PROT_READ);
}

void Unicorn::UcRegsInit()
{
    for (size_t Index = 0; Index < UcRegisters->GeneralPurposeUcRegisters.svUcIdsOfRegs.size(); ++Index)
    {
        uc_reg_write(uc, UcRegisters->GeneralPurposeUcRegisters.svUcIdsOfRegs[Index], &UcRegisters->GeneralPurposeUcRegisters.svUcValuesOfRegs[Index]);
    }

    for (size_t Index = 0; Index < UcRegisters->XmmUcRegisters.svUcIdsOfRegs.size(); ++Index)
    {
        uc_reg_write(uc, UcRegisters->XmmUcRegisters.svUcIdsOfRegs[Index], &UcRegisters->XmmUcRegisters.svUcValuesOfRegs[Index]);
    }
}

void Unicorn::UcRegsRead()
{

}

void Unicorn::UcRegsWrite()
{

}

Unicorn::Unicorn()
{
    ucHooks::_Hooks Hooks(InfoPe, UcRegisters);
    UcDefualtRegsInit();

    uc_err Error = uc_open(UC_ARCH_X86, UC_MODE_64, &uc);
    if (Error != UC_ERR_OK)
    {
        return;
    }

    //InfoPe->Path = "D:\\Programs\\Soft\\Coding\\C\\VisualStudio\\Coders\\PeVisor\\Samples\\Protected\\CrackMe1.exe";
    InfoPe->Path = "D:\\Programs\\Soft\\Coding\\MASM\\ASM Visual\\Coders\\MASM\\prog1\\bin\\Debug\\prog12.exe";
    //InfoPe->Path = "D:\\Programs\\Games\\Mafia series\\Mafia II Definitive Edition by xatab\\Unpacked\\pc\\Mafia II Definitive Edition.exe";
    Pe Pe(InfoPe, uc);

    UcDefualtSectionMapping();
    UcRegsInit();

    //////////////////////////////////////////////////////////////// HOOKS_SPACE
    //uc->insn_hook_validate = x86_insn_hook_validate;
    uc_hook_add(uc, &ucHookEdgeGenerated, UC_HOOK_EDGE_GENERATED, (void*)ucHooks::HookEdgeGenerated, &Hooks, 1, 0);
    uc_hook_add(uc, &ucHookBlock, UC_HOOK_BLOCK, (void*)ucHooks::HookBlock, &Hooks, 1, 0);
    uc_hook_add(uc, &ucHookCode, UC_HOOK_CODE, (void*)ucHooks::HookCode, &Hooks, 1, 0);
    uc_hook_add(uc, &ucHookInt, UC_HOOK_INTR, (void*)ucHooks::HookInt, &Hooks, 1, 0);
    //uc_hook_add(uc, &ucHookCall, UC_HOOK_INSN, (void*)ucHooks::HookCall, &Hooks, 1, 0, UC_X86_INS_CALL);
    //uc_tcg_op_code
    //UC_X86_INS_AAS
    //UC_X86_INS_CALL
    //////////////////////////////////////////////////////////////// HOOKS_SPACE

    //////////////////////////////////////////////////////////////// UNICORN_ENGINE_START
    Error = uc_emu_start(uc, InfoPe->PeStructure.EntryPoint, 0xFFFFFFFFFFFFFFFF - 1, 0, 0);
    if (Error)
    {
        printf("Failed on uc_emu_start() with error returned %u: %s\n", Error, uc_strerror(Error));

        return;
    }
    //////////////////////////////////////////////////////////////// UNICORN_ENGINE_START


    return;
}