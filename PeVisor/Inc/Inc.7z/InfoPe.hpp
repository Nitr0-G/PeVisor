#ifndef INFO_PE
#define INFO_PE

#include <basetsd.h>
#include <filesystem>
#include <vector>
#include <Windows.h>

enum class DefualtSizesForSectionMapping : const DWORD_PTR
{
	//https://wiki.osdev.org/Global_Descriptor_Table
	GdtSize = 0x10000,
	FsSize = 0x10000,
};

typedef struct _PE_STRUCTURE_
{
	std::vector<std::vector<IMAGE_SECTION_HEADER>> svSections;

	PIMAGE_DOS_HEADER DosHeader;
	PIMAGE_NT_HEADERS NtHeader;

	DWORD_PTR EntryPoint;
} _PeStructure, * PPeStructure;

typedef struct _INFO_PE_
{
	_PeStructure PeStructure;

	std::filesystem::path Path;
} _InfoPe, * PInfoPe;

#endif