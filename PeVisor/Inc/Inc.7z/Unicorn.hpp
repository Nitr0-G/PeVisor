#ifndef UNICORN_SHELL
#define UNICORN_SHELL

#include "Pe.hpp"
#include "UcHooks.hpp"
#include "UcRegisters.hpp"
#include "unicorn\unicorn.h"
#include <memory>
#include <xmmintrin.h>

class Unicorn {
private:
    uc_engine* uc = nullptr;
    uc_hook ucHookBlock = 0, ucHookCode = 0, ucHookEdgeGenerated = 0, ucHookInt = 0, ucHookCall = 0;
private:
	void UcRegsInit();
    void UcDefualtSectionMapping();
    void UcDefualtRegsInit();
public:
	std::shared_ptr<_InfoPe> InfoPe = std::make_shared<_InfoPe>();
	std::shared_ptr<_UcRegisters> UcRegisters = std::make_shared<_UcRegisters>();
public:
	void UcRegsRead();
	void UcRegsWrite();

	Unicorn();
};

#endif