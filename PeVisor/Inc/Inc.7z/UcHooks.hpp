#ifndef UNICORN_HOOKS
#define UNICORN_HOOKS

#include "InfoPe.hpp"
#include "UcRegisters.hpp"
#include "unicorn\unicorn.h"

namespace ucHooks {
	class _Hooks {
	public:
		std::shared_ptr<_InfoPe> InfoPe;
		std::shared_ptr<_UcRegisters> UcRegisters;

		_Hooks(std::shared_ptr<_InfoPe> infoPe, std::shared_ptr<_UcRegisters> ucRegisters) : InfoPe(infoPe), UcRegisters(ucRegisters) {};
	};

	void HookCode(uc_engine* uc, DWORD_PTR address, size_t size, void* user_data);
	void HookBlock(uc_engine* uc, DWORD_PTR address, size_t size, void* user_data);
	void HookEdgeGenerated(uc_engine* uc, DWORD_PTR address, size_t size, void* user_data);
	void HookInt(uc_engine* uc, DWORD_PTR address, size_t size, void* user_data);
}

#endif